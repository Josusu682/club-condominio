
// Datos de ejemplo — reemplaza por tu fuente real (Sheets/Supabase)
const JUGADORES = [
  { nombre: "Lucas Farías", edad: 13, apoderado: "Ana Farías", dpto: "Torre A 1204", estado: "al_dia" },
  { nombre: "Martina Soto", edad: 11, apoderado: "Carlos Soto", dpto: "Torre B 305", estado: "pendiente" },
  { nombre: "Diego Román", edad: 12, apoderado: "Paula Román", dpto: "Torre C 804", estado: "al_dia" },
];

const PAGOS = [
  { jugador: "Lucas Farías", apoderado: "Ana Farías", fecha: "2025-09-15", monto: 5000, metodo: "Webpay", estado: "Pagado" },
  { jugador: "Martina Soto", apoderado: "Carlos Soto", fecha: "2025-09-15", monto: 0, metodo: "—", estado: "Pendiente" },
  { jugador: "Diego Román", apoderado: "Paula Román", fecha: "2025-09-08", monto: 20000, metodo: "Transferencia", estado: "Pagado" },
];

function renderJugadores() {
  const tbody = document.querySelector("#tabla-jugadores tbody");
  if (!tbody) return;
  tbody.innerHTML = "";
  JUGADORES.forEach(j => {
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td>${j.nombre}</td>
      <td>${j.edad}</td>
      <td>${j.apoderado}</td>
      <td>${j.dpto}</td>
      <td>${j.estado === "al_dia" ? "Al día" : "Pendiente"}</td>
    `;
    tbody.appendChild(tr);
  });
}

function renderPagos() {
  const tbody = document.querySelector("#tabla-pagos tbody");
  if (!tbody) return;
  const filtro = document.getElementById("filtro-pagos")?.value || "todos";
  tbody.innerHTML = "";
  PAGOS
    .filter(p => {
      if (filtro === "aldia") return p.estado === "Pagado";
      if (filtro === "pendiente") return p.estado === "Pendiente";
      return true;
    })
    .forEach(p => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${p.jugador}</td>
        <td>${p.apoderado}</td>
        <td>${p.fecha}</td>
        <td>${p.monto}</td>
        <td>${p.metodo}</td>
        <td>${p.estado}</td>
      `;
      tbody.appendChild(tr);
    });
}

function filtrarPagos() {
  renderPagos();
}

// Exportación rápida a CSV (del array actual mostrado)
function exportarCSV() {
  const rows = [["Jugador","Apoderado","Fecha","Monto","Método","Estado"]];
  const filtro = document.getElementById("filtro-pagos")?.value || "todos";
  PAGOS
    .filter(p => {
      if (filtro === "aldia") return p.estado === "Pagado";
      if (filtro === "pendiente") return p.estado === "Pendiente";
      return true;
    })
    .forEach(p => rows.push([p.jugador, p.apoderado, p.fecha, p.monto, p.metodo, p.estado]));

  const csv = rows.map(r => r.map(field => `"${String(field).replace(/"/g,'""')}"`).join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "pagos.csv";
  a.click();
  URL.revokeObjectURL(url);
}
