
# Club de Fútbol del Condominio — Site estático (GitHub Pages)

Sitio estático para gestionar un pequeño club: próximos partidos, registro de jugadores y **enlaces de pago**.
> **Importante:** Este prototipo no procesa pagos por sí mismo; usa **links de pago** (PayPal/Flow/Mercado Pago/Webpay) y **Google Forms** para recibir comprobantes.

## Deploy rápido en GitHub Pages
1. Crea un repo llamado `club-condominio` en tu cuenta.
2. Sube estos archivos (carpeta completa).
3. Entra a **Settings → Pages → Build and deployment** y elige:
   - **Source**: *Deploy from a branch*
   - **Branch**: `gh-pages` (se creará con el workflow) o `main` si no usas el workflow.
4. (Recomendado) Deja el **workflow** de GitHub Actions que publica en `gh-pages` al hacer push a `main`.

## Ajustes pendientes
- Reemplaza `PAGO_LINK_UNICO` por tu link de pago del partido.
- Reemplaza `GOOGLE_FORM_URL` por tu formulario para subir comprobantes.
- Si usas Vite/React en el futuro, recuerda ajustar `base` y usar HashRouter.

## Estructura
```
index.html
calendario.html
jugadores.html
pagos.html
assets/
  css/styles.css
  js/app.js
.github/workflows/deploy.yml
```

## Notas
- Puedes embeber un Google Calendar en `calendario.html`.
- Para una tabla "al día vs. pendiente" automática, considera usar Google Sheets + Apps Script o pasar a Supabase/Firebase.
